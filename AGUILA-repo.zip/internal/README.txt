Private working notes.

This folder is gitignored. Nothing here is ever committed or published.
Use it for anything you want to keep local: rough calculations, supplier quotes,
half-formed ideas, notes you would not want a recruiter reading.
